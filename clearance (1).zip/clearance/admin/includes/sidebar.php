
<aside class="main-sidebar">
    <section class="sidebar">
        <ul class="sidebar-menu">
            <li class="treeview">
			 
				<a href="faculty.php">
                    <i class="fa fa-dashboard"></i><span>Faculty</span>
                </a>
				<a href="department.php">
                    <i class="fa fa-dashboard"></i><span>Department</span>
                </a>
				<a href="calendar.php">
                    <i class="fa fa-dashboard"></i><span>Session</span>
                </a>
				<a href="fees.php">
                    <i class="fa fa-dashboard"></i><span>Fees</span>
                </a>
				<a href="students.php">
                    <i class="fa fa-dashboard"></i><span>Students</span>
                </a>
				<a href="users.php">
                    <i class="fa fa-dashboard"></i><span>Users</span>
                </a>

				 <a href="logout.php">
                    <i class="fa fa-dashboard"></i><span>Logout</span>
                </a>
            </li>
        </ul>
    </section>
</aside>
