<header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"></span>
        <!-- logo for regular state and mobile devices -->
        <span style="float:left"></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
     
</header>
<span style="float:right;padding-right:50px;"></span>